Isidore
=======

Isidore is a database, API, and CLI for managing Ansible inventories. It allows
for a flexible tag base classification approach to group management.

Website: [https://github.com/Z5T1/isidore](https://github.com/Z5T1/isidore)

